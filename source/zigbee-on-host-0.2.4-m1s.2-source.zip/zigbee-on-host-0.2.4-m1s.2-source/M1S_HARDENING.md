# ZoH M1S hardening 0.2.4-m1s.2

This branch keeps the `zigbee-on-host` 0.2.4 public API used by
Zigbee2MQTT 2.14.2 and hardens the failure paths observed with an Aqara M1S
JN5189 OpenThread RCP coordinator.

## Changes

- Allocate the complete IEEE 802.15.4 MAC frame size of 127 bytes. The
  upstream 0.2.4 buffer was 116 bytes and upstream 0.3.1 only raises it to
  118 bytes; both sizes describe payload capacity, not the complete encoded
  frame.
- Reject frames larger than 127 bytes explicitly instead of allowing a
  truncated copy or a late `Buffer.writeUInt16LE` exception.
- Limit secured coordinator Link Status frames to 26 entries and fragment
  larger neighbor lists with the required one-entry overlap.
- Drop malformed HDLC/Spinel input frames with rate-limited diagnostics so a
  single bad FCS does not terminate Zigbee2MQTT.
- Retry the five read-only Spinel identity queries during startup, allowing a
  dropped response to recover without restarting Zigbee2MQTT.
- Remove expired Spinel transaction waiters instead of leaving stale entries.
- Register each Spinel response waiter before writing the request, preventing
  fast RCP responses from arriving before their transaction is tracked.
- Discard transport noise that does not contain an HDLC flag.
- Register the RCP reset waiter before sending the reset command.
- Do not save network state when startup failed before state was loaded.
- Keep the explicitly configured transmit power when loading saved state.
- Save network state through a temporary file, retain the previous complete
  snapshot, and recover it automatically when the primary save is incomplete.
- Require the state-file end marker so a power-interrupted write cannot be
  mistaken for a complete network snapshot.
- Reconcile a changed short address from LINK_STATUS only when its extended
  IEEE address matches an already authorized device. Remove only that same
  device's stale mapping, reject addresses owned by another IEEE, and persist
  the repaired network state immediately.
- Serialize periodic state snapshots so address recovery and the timer cannot
  overwrite the same temporary file concurrently. A failed persistence attempt
  is logged without aborting radio-frame processing.

## Verification

- TypeScript development and production builds pass.
- All 56 NWK handler tests pass.
- Ten focused driver tests pass, including malformed HDLC recovery, startup
  property retry, parser resynchronization, state loading, and RCP reset
  behavior.
- All 35 stack-context tests pass, including recovery from a deliberately
  truncated primary state file.
- All 81 MAC compliance and encryption/decryption tests pass.
- A regression test reproduces the former 24-neighbor, 119-byte Link Status
  frame and verifies successful encoding.
- A 52-neighbor regression test verifies fragmentation into three MAC frames,
  each no larger than 127 bytes.
- Regression tests cover authorized address recovery, state persistence, and
  refusal to overwrite a conflicting IEEE-to-short-address mapping.
- A stack-context regression test covers overlapping periodic save requests.

This is a test build. It should be validated on a non-critical coordinator
before replacing a running Zigbee2MQTT installation.
